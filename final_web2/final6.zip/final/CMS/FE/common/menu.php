<?php

function menu()
{
?>
    <!-- Start Top Nav -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-light d-none d-lg-block" id="templatemo_nav_top">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <i class="fa fa-envelope mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="mailto:info@company.com">ClairéJewels@company.com.lb</a>
                    <i class="fa fa-phone mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="tel:010-020-0340">01 123 123</a>
                </div>
                <div>
                    <a class="text-light" href="https://fb.com/templatemo" target="_blank" rel="sponsored"><i class="fab fa-facebook-f fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.linkedin.com/" target="_blank"><i class="fab fa-linkedin fa-sm fa-fw"></i></a>
                </div>
            </div>
        </div>

    </nav>
    <!-- Close Top Nav -->

    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-light shadow">
        <div class="container d-flex justify-content-between align-items-center">

            <a class="navbar-brand text-success logo h1 align-self-center" href="about.php">
                ClairéJewels
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="align-self-center collapse navbar-collapse flex-fill  d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
                <div class="flex-fill">
                    <ul class="nav  navbar-nav d-flex  mx-lg-auto">

                        <li class="nav-item">
                            <a class="nav-link" href="about.php" style="margin-left: 5.6rem;">Add Item</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shop.php" style="margin-left: 4.6rem;">Shop</a>
                        </li>

                    </ul>
                </div>
                <div class="navbar align-self-center d-flex">
                    <div class="d-lg-none flex-sm-fill mt-3 mb-4 col-7 col-sm-auto pr-3">
                        <div class="input-group">
                        </div>
                    </div>
                    <a class="nav-icon d-none d-lg-inline" href="../../public_website/FE/about.php" data-bs-toggle="modal" data-bs-target="">
                        <span style="color: rgb(27, 76, 17); padding: 10px 20px; border: 2px solid rgb(27, 76, 17);border-radius: 5px; cursor: pointer; transition: background-color 0.3s;font-weight: 600;">Preview Client Site</ispan>
                    </a>
                    <a class="nav-icon position-relative text-decoration-none" href="signup.php">
                        <span style="background-color: rgb(9, 99, 25); color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s;">Add Admin</span>
                    </a>
                    <!---------------------NEED TO ADD WELCOME MSG-->

                    <span style="color: rgb(27, 76, 17); padding: 10px 20px; padding-left: 0px; cursor: pointer; transition: background-color 0.3s;font-weight: 600;">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>

                    <form action="../BE/logout.php" method="POST" class="logout-form">
                        <button type="submit" class="logout-button" style="background-color: rgb(80, 95, 83); color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s;">Logout</button>
                    </form>

                </div>
            </div>

        </div>
    </nav>
    <!-- Close Header -->
<?php
}
?>