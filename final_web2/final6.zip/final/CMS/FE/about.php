<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("location:../../public_website/FE/about.php");
}
// require_once("../BE/controller/jewelry.php");
require_once("common/menu.php");
require_once("common/footer.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>ClairéJewels - About Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/additem.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!--
    
TemplateMo 559 ClairéJewels

https://templatemo.com/tm-559-ClairéJewels

-->
</head>

<body>

    <?php echo menu(); ?>

    <!-- Modal -->
    <div class="modal fade bg-white" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="w-100 pt-1 mb-5 text-right">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
        </div>
    </div>
    <!-- add jewelry -->
    <section class="bg-success py-5">
        <div class="container-table">
            <div class="row align-items-center py-5">
                <div class="col-md-8 text-white">
                    <h1>Add An Item</h1>
                    <form action="../BE/jewelry.php" method="POST" id="#">
                        <div class="input-box">
                            <div class="input-field">
                                <label for="name">Name Of Jewelry</label>
                                <br>
                                <input type="text" placeholder="bracelet1" name="name" required>
                            </div>
                            <div class="input-field">
                                <label for="type">Type Of Jewelry</label>
                                <br>
                                <input type="text" placeholder="Bracelet" name="type" required>
                            </div>
                            <div class="input-field">
                                <label for="price">Price</label>
                                <br>
                                <input type="number" placeholder="0" name="price" required>
                            </div>
                        </div>
                        <input type="submit" class="btn" value="AddItem">
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Close Banner -->

    <?php echo footer(); ?>

    <!-- Start Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->
</body>

</html>