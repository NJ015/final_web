<?php
    // session_start();
    // if (isset($_SESSION["username"])) {
    //     header("location:../FE/login.php");
    // }

?>
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> 
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/templatemo.css">
        <link rel="stylesheet" href="assets/css/login.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
        <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    </head>

    <body>
        <header class = "header">
       
        <div class="wrapper">
            <form action="../BE/login.php" method="POST" id="login-form">
                <h1>Login</h1>
                <div class="input-box">
                    <i class="fa-solid fa-user"></i> Username</a>
                    <input type="text" placeholder="Username" id="un" name="username" required>
                </div>
                <div class="input-box">
                    <i class="fa-solid fa-lock"></i> Password</a>
                    <input type="password" placeholder="Password" id="pass" name="password" required>
                </div>
                <br>
                <div class="forgetpass"><a href="forgetPass.php"> Forget Password?</a></div>
                <input type="button" class="btn" value="Login" onclick="login()">
            
        </form>
        </div>

        <script>
            function login(){
                var un = document.getElementById("un").value;
                var pass = document.getElementById("pass").value;

                if ((un == "") || (pass == "")){
                    alert("You must fill in the username and the password!");
                }
                else{
                    document.getElementById("login-form").submit();
                }
            }

            function ClearForm(){ // to clear the form
                document.getElementById("un").value="";
                document.getElementById("pass").value="";
            }
        </script>
    </body>
</html>