<?php
    session_start();
    if (!isset($_SESSION["username"])){
        header("location:../../public_website/FE/about.php");
    }
?>
<html>
    <head>
        <title>Signup</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> 
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/templatemo.css">
        <link rel="stylesheet" href="assets/css/login.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
        <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    </head>

    <body>
        <header class = "header">
       
        <div class="wrapper">
            <form action="../BE/signup.php" method="POST" id="signup-form">
                <h1>Add Admin</h1>
                <div class="input-box">
                    <i class="fa-solid fa-user"></i> Username</a>
                    <input type="text" placeholder="Username" id="un" name="username" required>
                </div>
                <div class="input-box">
                    <i class="fa-solid fa-lock"></i> Password</a>
                    <input type="password" placeholder="Password" id="pass" name="password" required>
                </div>
                <br>
                <input type="button" class="btn" value="Signup" onclick="signup()">
            
        </form>
        </div>

        <script>
            function signup(){
                var un = document.getElementById("un").value;
                var pass = document.getElementById("pass").value;

                if ((un == "") || (pass == "")){
                    alert("You must fill in the username and the password!");
                }
                else{
                    document.getElementById("signup-form").submit();
                }
            }

            function ClearForm(){ // to clear the form
                document.getElementById("un").value="";
                document.getElementById("pass").value="";
            }
        </script>
    </body>
</html>