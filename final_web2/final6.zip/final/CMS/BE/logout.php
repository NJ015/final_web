<?php
function logout(){
        session_start();
        $_SESSION = array();
        session_destroy();
        header("Location:../../public_website/FE/about.php"); 
        exit;
}


logout();

?>