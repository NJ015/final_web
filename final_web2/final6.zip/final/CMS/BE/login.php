<?php
// function login()
// {
//     require_once("common/function.php");
//     $db = DBConncet();
    
//     $query = "select ID from tbl_users where USERNAME='" . $un . "' AND PASSWORD='" . $pass . "'";

//     $un = $_POST["username"];
//     $pass = $_POST["password"];
//     $query = "select ID from tbl_users where USERNAME='" . $un . "' AND PASSWORD='" . $pass . "'";
//     $stmt = $db->query($query);
//     $rowCount = $stmt->rowCount();
//     // echo $rowCount;
//     if ($rowCount > 0) {
//         session_start();
//         $_SESSION["username"] = $un;
//         header("location:../FE/about.php");
//     } else {
//         header("location:../FE/about.php");  // add script and redirection to client website
//     }
// }
function login()
{
    require_once("common/function.php");
    $db = DBConncet();

    $un = $_POST["username"];
    $pass = $_POST["password"];

    // Retrieve the hashed password from the database
    $query = "SELECT ID, PASSWORD FROM tbl_users WHERE USERNAME=?";
    $stmt = $db->prepare($query);
    $stmt->execute([$un]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Verify hashed password
        if (password_verify($pass, $user['PASSWORD'])) {
            session_start();
            $_SESSION["username"] = $un;
            header("location:../FE/about.php");
            exit; // Always exit after header redirect
        }
    }

    // Incorrect username or password
    header("location:../FE/about.php");
    exit; // Always exit after header redirect
}


login();
