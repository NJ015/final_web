<?php

    // function login()
    // {
    //     require_once("common/function.php");
    //     $db = DBConncet();

    //     $un = $_POST["username"];
    //     $pass = $_POST["password"];

    //     $query = "select ID from tbl_users where USERNAME='" . $un . "' AND PASSWORD='" . $pass . "'";
    //     $stmt = $db->query($query);
    //     $rowCount = $stmt->rowCount();
    //     // echo $rowCount;
    //     if ($rowCount > 0) {
    //         session_start();
    //         $_SESSION["username"] = $un;
    //         header("location:../FE/about.php");
    //     } else {
    //         header("location:../FE/about.php");
    //     }
    // }
    function login()
{
    require_once("common/function.php");
    $db = DBConncet();

    $un = $_POST["username"];
    $pass = $_POST["password"];

    // Retrieve the hashed password from the database
    $query = "SELECT ID, PASSWORD FROM tbl_users WHERE USERNAME=?";
    $stmt = $db->prepare($query);
    $stmt->execute([$un]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Verify hashed password
        if (password_verify($pass, $user['PASSWORD'])) {
            session_start();
            $_SESSION["username"] = $un;
            header("location:../FE/about.php");
            exit; // Always exit after header redirect
        }
    }

    // Incorrect username or password
    header("location:../FE/about.php");
    exit; // Always exit after header redirect
}


    function add_jewelry($obj)
    {
        $db = DBConncet();
        $query = "INSERT INTO tbl_jewelry (`NAME`,`TYPE`,`PRICE`) VALUES ('$obj->name','$obj->type',$obj->price)";
        $stmt = $db->query($query);
        $rowCount = $stmt->rowCount();
        if ($rowCount>0) {
            echo "<script>
            alert('Jewelry added successfully!');
            window.location.href='../FE/about.php';
            </script>";
        } else {
            echo "<script>
            alert('Error: Failed to add jewelry!');
            window.location.href='../FE/about.php';
            </script>";
        }
    }

    function ChangeStatus($id, $status)
    {
        $db = DBConncet();
        $query = "UPDATE tbl_jewelry SET `IS_ACTIVE`=$status where ID=$id";
        echo $query;
        $stmt = $db->query($query);
    }

    function getall()
    {
        $db = DBConncet();
        $query = "SELECT * FROM tbl_jewelry";
        $stmt = $db->query($query);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    // function signup()
    // {
    //     require_once("common/function.php");
    //     $db = DBConncet();
    //     $un = VarExist($_POST["username"]);
    //     $pass = VarExist($_POST["password"]);
    //     // $query = "INSERT INTO tbl_users (`USERNAME`,`PASSWORD`) VALUES ('$un','$pass')";
    //     $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    //     // SQL query with hashed password
    //     $sql = "INSERT INTO `tbl_users`(`USERNAME`, `PASSWORD`) VALUES ('$username', '$hashedPassword')";
    //     $stmt = $db->query($query);

    //     // Check if the query was successful before redirecting
    //     if ($stmt) {
    //         echo "<script>
    //         alert('User added successfully!');
    //         window.location.href='../FE/about.php';
    //         </script>";
    //     } else {
    //         // Handle error if the query fails
    //         echo "<script>
    //         alert('Error: Failed to add user!');
    //         window.history.back();
    //         </script>";
    //     }
    // }
    function signup()
{
    require_once("common/function.php");
    $db = DBConncet();

    $un = VarExist($_POST["username"]);
    $pass = VarExist($_POST["password"]);

    // Hash the password
    $hashedPassword = password_hash($pass, PASSWORD_DEFAULT);

    // SQL query with hashed password
    $sql = "INSERT INTO `tbl_users`(`USERNAME`, `PASSWORD`) VALUES ('$un', '$hashedPassword')";
    $stmt = $db->query($sql); // Execute the SQL query

    // Check if the query was successful before redirecting
    if ($stmt) {
        echo "<script>
        alert('User added successfully!');
        window.location.href='../FE/about.php';
        </script>";
    } else {
        // Handle error if the query fails
        echo "<script>
        alert('Error: Failed to add user!');
        window.history.back();
        </script>";
    }
}


    function logout()
    {
        session_start();
        $_SESSION = array();
        session_destroy();
        header("Location:../../public_website/FE/about.php");
        exit;
    }
?>