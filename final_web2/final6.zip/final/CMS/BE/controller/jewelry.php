<?php
    require_once("../common/function.php");
    require_once("../jewelry_model/jewelry.php");


    if (isset($_POST['id']) && isset($_POST['status'])) {
        $id = ($_POST["id"]);
        $status = ($_POST["status"]);
        ChangeStatus($id, $status);
        header("location:../../FE/shop.php");
    }
    elseif (isset($_POST['action'])=='addJewelry' && isset($_POST['name']) && isset($_POST['type']) && isset($_POST['price'])) {
        $obj = new stdClass();
        $obj->name=VarExist($_POST["name"]);
        $obj->type=VarExist($_POST["type"]);
        $obj->price=VarExist($_POST["price"]);
        add_jewelry($obj);
    }
    elseif (isset($_POST['action'])=='logout') {
        logout();
    }
    elseif (isset($_POST['action'])=='signup') {
        signup();
    }




?>