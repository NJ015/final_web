<?php
// function signup()
// {
//     require_once("common/function.php");
//     $db = DBConncet();
//     $un = VarExist($_POST["username"]);
//     $pass = VarExist($_POST["password"]);
//     // $query = "INSERT INTO tbl_users (`USERNAME`,`PASSWORD`) VALUES ('$un','$pass')";
//     $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

//     // SQL query with hashed password
//     $sql = "INSERT INTO `tbl_users`(`USERNAME`, `PASSWORD`) VALUES ('$username', '$hashedPassword')";
//     $stmt = $db->query($query);

//     // Check if the query was successful before redirecting
//     if ($stmt) {
//         echo "<script>
//         alert('User added successfully!');
//         window.location.href='../FE/about.php';
//         </script>";
//     } else {
//         // Handle error if the query fails
//         echo "<script>
//         alert('Error: Failed to add user!');
//         window.history.back();
//         </script>";
//     }
// }
function signup()
{
    require_once("common/function.php");
    $db = DBConncet();

    $un = VarExist($_POST["username"]);
    $pass = VarExist($_POST["password"]);

    // Hash the password
    $hashedPassword = password_hash($pass, PASSWORD_DEFAULT);

    // SQL query with hashed password
    $sql = "INSERT INTO `tbl_users`(`USERNAME`, `PASSWORD`) VALUES ('$un', '$hashedPassword')";
    $stmt = $db->query($sql); // Execute the SQL query

    // Check if the query was successful before redirecting
    if ($stmt) {
        echo "<script>
        alert('User added successfully!');
        window.location.href='../FE/about.php';
        </script>";
    } else {
        // Handle error if the query fails
        echo "<script>
        alert('Error: Failed to add user!');
        window.history.back();
        </script>";
    }
}

signup();
