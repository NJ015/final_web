<?php
    require_once("../common/function.php");
    require_once("../jewelry_model/jewelry.php");


    if (isset($_POST['action'])=='getList') {
        getall();
    }
    elseif (isset($_POST['action'])=='contact' && isset($_POST['name']) && isset($_POST['email']) && isset($_POST['subject']) && isset($_POST['message'])) {
        $obj = new stdClass();
        $obj->name=VarExist($_POST["name"]);
        $obj->email=VarExist($_POST["email"]);
        $obj->sub=VarExist($_POST["subject"]);
        $obj->mess=VarExist($_POST["message"]);
        add_contactInfo($obj);
    }
    elseif (isset($_POST[''])=='') {
        //if you need it
    }

?>