<?php

function add_contactInfo($obj)
{
  $db = DBConncet();
  $query = "INSERT INTO tbl_contact (`NAME`,`EMAIL`,`SUBJECT`,`MESSAGE`) VALUES ('$obj->name','$obj->email','$obj->sub','$obj->mess')";
  $stmt = $db->query($query);
  if ($stmt) {
    echo "<script>
     alert('Message sended succesfully!');
     window.location.href='../FE/about.php';
     </script>";
  } else {
    // Handle error if the query fails
    echo "<script>
     alert('Error: Failed to send the message!');
     window.history.back();
     </script>";
  }
}

function getall()
{
  $db = DBConncet();
  $query = "SELECT * FROM tbl_jewelry WHERE `IS_ACTIVE`>0";
  $stmt = $db->query($query);
  $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
  return $results;
}

function getByCategory($category)
{
  $db = DBConncet();
  $query = "SELECT * FROM tbl_jewelry WHERE `IS_ACTIVE`>0 AND `TYPE`='$category'";
  $stmt = $db->query($query);
  $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
  return $results;
}
