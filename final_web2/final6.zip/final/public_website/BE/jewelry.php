<?php
require_once("common/function.php");

function getall(){
    $db = DBConncet();
    $query="SELECT * FROM tbl_jewelry WHERE `IS_ACTIVE`>0";
    $stmt=$db->query($query);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $results;
}

function getByCategory($category)
{
  $db = DBConncet();
  $query = "SELECT * FROM tbl_jewelry WHERE `IS_ACTIVE`>0 AND `TYPE`='$category'";
  $stmt = $db->query($query);
  $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
  return $results;
}

